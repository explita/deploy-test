# Changelog

All notable changes to `@explita/protocol` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-10-14

### Added
- **Core Schemas & Project Config**: Published JSON Schema definition (`schema.json`) for `explita.json` project configuration covering `deploy` and `tunnel` settings, with helper normalizers for health checks, pre-deploy hooks, custom domains, and crons (`loadProjectConfig`, `saveProjectConfig`, `defineConfig`).
- **Deploy & Application Contracts**: Contract definitions for apps, zero-downtime rolling deployments, live deployment event streaming (`DeploymentStreamEvent`), domain routing, and resource constraints (`AppResourcesMetadata`).
- **Cron Scheduling Engine**: Standard 5-field cron parser with macro support (`@daily`, `@hourly`, etc.), real-time schedule matcher (`matchesCron`), next execution calculator (`getNextCronRun`), and human-readable schedule describer (`describeCron`).
- **Database, Backups & S3 Replication**: Contracts for managed PostgreSQL, MariaDB, and Redis instances, automated database backup schedules, full-system/app dump manifests (`DumpManifest`), and S3 storage synchronization contracts (`S3Config`, `S3Status`).
- **Docker Volume Management**: Added persistent storage models (`VolumeItem`, `VolumeAppBinding`, `VolumeListResult`, `VolumeInspectResult`) and volume binding parsing/normalization utilities (`parseVolumeBinding`, `normalizeVolumes`).
- **Preview Deployments**: Added preview deployment state and HTTP Basic Auth configuration contracts (`preview.auth`), along with preview subdomain and container naming derivation utilities.
- **Incident & Health Notifications**: Multi-channel alert contracts and rich payload formatters for Discord, Slack, and Telegram with event filtering (`container_healthy`, `container_unhealthy`, `deployment_failed`, `cron_failed`, `backup_completed`, `backup_failed`).
- **Maintenance Mode & System Telemetry**: Contracts for instant 503 maintenance mode (`MaintenanceConfig`), real-time container CPU/memory/IO telemetry (`ContainerStat`), and server diagnostics (`SystemDiagnostics`).
- **Tunnel Wire Protocol & E2EE**: WebSocket binary/text message schemas, streaming response frames (`StreamSender`), end-to-end encryption via ephemeral ECDH (`prime256v1`) / HKDF SHA-256 / AES-256-GCM, session fingerprinting (`computeFingerprint`), and client IP/CIDR firewall filtering (`isIpAllowed`, `parseCidr`).
- **Global Config & Security Utilities**: User configuration persistence (`~/.explita/config.json`), AES-256-GCM environment encryption/decryption (`encryptValue`, `decryptValue`), VPS public IP auto-resolution with caching (`getServerPublicIp`), and core infrastructure protection checks (`isCoreInfraContainer`).
