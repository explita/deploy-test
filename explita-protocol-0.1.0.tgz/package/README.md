# @explita/protocol

Part of the **Explita Infra** ecosystem.

## Schema

```
https://unpkg.com/@explita/protocol/schema.json
```

## License

MIT
