# @explita/protocol

Part of the **Explita Infra** ecosystem.

## Schema

```
https://infra.explita.ng/config/schema.json
```

## License

MIT
